from module.meme.function.neon import neon

__all__ = {"neon": neon, "点击咨询": neon}
